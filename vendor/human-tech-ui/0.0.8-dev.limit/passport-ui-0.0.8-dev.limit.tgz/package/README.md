# Human.Tech passport UI

This private subset of @human.tech/ui replaces the full package in passport
consumers. Install one archive per app; use the full archive for multiple products.

```tsx
import { Button } from '@human.tech/ui/core'
import { PassportApp } from '@human.tech/ui/passport'
import '@human.tech/ui/core.css'
import '@human.tech/ui/passport.css'
```

Only the core and passport JavaScript entries are public. Required transitive
dependencies are included internally. Serve dist/graphics and dist/lottie (when
present) at /graphics and /lottie for components using default runtime URLs.
Proprietary; for Holonym Foundation and human.tech products only.
